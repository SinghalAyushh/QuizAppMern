require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const User = require("./models/user");
const Quiz = require("./models/quiz");
const quizAPI = require("./quiz");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = parseInt(10);

app.use(cors());
app.use(express.json());

const uri = "mongodb+srv://Ayush:Ayush%400920@cluster0.ld0rwvf.mongodb.net/?retryWrites=true&w=majority";
;
mongoose.connect(uri).then((res)=>{
  console.log('MongoDb Connected')
}).catch((err)=>{
  console.log(err)
}
);

app.post("/api/register", (req, res) => {
  try {
    bcrypt.hash(req.body.password, saltRounds, function (err, hash) {
      if (err) {
        console.log(err);
        return res.status(500).json({
          status: "error",
          message: "Error while Saving",
        });
      } else {
        User.create({
          name: req.body.username,
          userId: req.body.userId,
          email: req.body.email,
          password: hash,
        });
        return res.json({ status: "ok" });
      }
    });
  } catch (err) {
    return res.json({ status: "error", error: "duplicate email" });
  }
});

app.post("/api/login", async (req, res) => {
  let user
if(req.body.email.includes("@")){
   user = await User.findOne({
    email: req.body.email,
  });
}else{
     user = await User.findOne({
      userId: parseInt(req.body.email),
    });
  }

  console.log(user)
  if (user) {
    bcrypt.compare(req.body.password, user.password, function (err, result) {
      if (result) {
        const token = jwt.sign(
          {
            email: user.email,
          },
          process.env.JWT_SECRET,
          { expiresIn: "5h" }
        );
        return res.json({
          status: "ok",
          token: token,
          user: user
        });
      } else {
        return res.json({
          status: "error",
          message: "Invalid Password",
        });
      }
    });
  } else {
    return res.json({ status: "error", message: req.body.email.includes("@")? "Email-Id is not registerd ":'Phone Number is not registerd' });
  }
});

app.post("/api/quiz", async (req, res) => {
  try {
    const token = req.headers["x-access-token"];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded) {
      const email = decoded.email;
      const user = await User.findOne({
        email: email,
      });
      if (user) {
        const quizData = await quizAPI(req.body.category, req.body.difficulty);
        const quiz = await Quiz.create({
          user: user._id,
          category: req.body.category,
          difficulty: req.body.difficulty,
        });
        return res.json({
          status: "ok",
          quizId: quiz._id,
          quizData: quizData,
        });
      } else {
        return res.json({
          status: "error",
          message: "User not found",
        });
      }
    } else {
      return res.json({ status: "error", message: "Invalid Token" });
    }
  } catch (err) {
    return res.json({ status: "error", message: "Invalid Token" });
  }
});

app.post("/api/result", async (req, res) => {
  try {
    const token = req.headers["x-access-token"];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded) {
      const email = decoded.email;
      const user = await User.findOne({
        email: email,
      });
      if (user) {
        const quiz = await Quiz.updateOne(
          { _id: req.body.quizId },
          { score: req.body.score }
        );
        return res.json({
          status: "ok",
        });
      } else {
        return res.json({
          status: "error",
          message: "User not found",
        });
      }
    } else {
      return res.json({ status: "error", message: "Invalid Token" });
    }
  } catch (err) {
    return res.json({ status: "error", message: "Invalid Token" });
  }
});

app.get("/api/result/:quizId", async (req, res) => {
  try {
    const token = req.headers["x-access-token"];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded) {
      const email = decoded.email;
      const user = await User.findOne({
        email: email,
      });
      if (user) {
        const quiz = await Quiz.findOne({
          _id: req.params.quizId,
        });
        return res.json({
          status: "ok",
          score: quiz.score,
        });
      } else {
        return res.json({
          status: "error",
          message: "User not found",
        });
      }
    } else {
      return res.json({ status: "error", message: "Invalid Token" });
    }
  } catch (err) {
    return res.json({ status: "error", message: "Invalid Token" });
  }
});

app.get("/api/history", async (req, res) => {
  try {
    const token = req.headers["x-access-token"];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded) {
      const email = decoded.email;
      const user = await User.findOne({
        email: email,
      });
      if (user) {
        const quiz = await Quiz.find({
          user: user._id,
        });
        return res.json({
          status: "ok",
          data: quiz,
        });
      } else {
        return res.json({
          status: "error",
          message: "User not found",
        });
      }
    } else {
      return res.json({ status: "error", message: "Invalid Token" });
    }
  } catch (err) {
    return res.json({ status: "error", message: "Invalid Token" });
  }
});

app.listen(5000, () => {
  console.log("Server is running on port 5000");
});
